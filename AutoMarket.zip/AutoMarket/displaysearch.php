<?php
$pageTitle = "CarSite - Search Results";
include_once 'includes/header.php';
?>

</head>

<body>

  <?php include_once "includes/navbar.php"; ?>

<?php
  function displayVehicles($conn, $result, $search_string = NULL) {
    $uid = $_SESSION['u_id'];
    if (!empty($search_string)) {
      echo '
      <div class="container-fluid">
        <header class="grid-header">
          <h1 class="text-center my-2"><span class="bg-white px-2">Search results for: <small>'.$search_string.'</small></span></h1>
        </header>
        <div class="wrapper mx-auto">
        <!-- <div class="d-flex flex-wrap justify-content-center align-content-start"> -->
          ';
        } else {
          echo '
          <div class="container-fluid">
            <header class="grid-header">
              <h1 class="text-center my-2">All Vehicles:</h1>
            </header>
            <div class="wrapper mx-auto">
            <!-- <div class="d-flex flex-wrap justify-content-center align-content-start"> -->
              ';
        }
      // Display the results in cards
      while ($row = mysqli_fetch_assoc($result)) {
        // str_replace is used to remove _model from vehicles with model names which are to short to be indexed for fulltext search
        echo '
        <div class="panel-g bg-light">
          <!-- <div class="card m-2" style="width:100%"> -->
            <img class="card-img-top" src="'.$row['image1'].'" alt="Car image">
            <!-- https://pixabay.com/vectors/auto-sepia-automotive-flat-design-3071895/ -->
            <div class="card-body">
              <h4 class="card-title text-uppercase">'.$row['make'].' '.str_replace('_model', '', $row['model']).'</h4>
              <p class="card-text">Year: '.$row['year'].'</p>
              <p class="card-text text-capitalize">Engine: '.$row['engine'].'</p>
              <p class="card-text">Engine Capacity: '.$row['size'].'</p>
              <p class="card-text text-capitalize">Colour: '.$row['colour'].'</p>
              <!-- <a href="#" class="btn btn-primary">See Profile</a> -->
              <div class="d-flex flex-row-reverse">';
              // determine if user has already liked the vehicle
              $results = mysqli_query($conn, "SELECT * FROM saved_vehicles WHERE id_user=$uid AND id_vehicle=".$row['idvehicle']."");
              // if user has liked the vehicle echo this
              if (mysqli_num_rows($results) == 1) {
                echo '
                <button data-id="'.$row['idvehicle'].'" class="unlike btn btn-danger"><i class="fa fa-heart" aria-hidden="true"></i></button>
                <button data-id="'.$row['idvehicle'].'" class="like hidden btn btn-danger"><i class="fa fa-heart-o" aria-hidden="true"></i></button>
                ';
              } else {
                echo '
                <button data-id="'.$row['idvehicle'].'" class="unlike hidden btn btn-danger"><i class="fa fa-heart" aria-hidden="true"></i></button>
                <button data-id="'.$row['idvehicle'].'" class="like btn btn-danger"><i class="fa fa-heart-o" aria-hidden="true"></i></button>
                ';
              }
              echo '
              </div>
            </div>
          <!-- </div> -->
        </div>
        ';
      }
      echo '</div>
      </div>';
  }
  if (isset($_SESSION['u_id'])){
    include "includes/dbh.inc.php";
    $uid = $_SESSION['u_id'];
    // echo "search results <br>".$_POST['search'];
    if (isset($_POST['submit-search'])) {
      $search_string = mysqli_real_escape_string($conn, $_POST['search-cars']);
      // seperate search string from post into key words array
      $search_array = explode(" ", $search_string);
      // create fulltext search string
      $search = "";
      foreach ($search_array as $keyword) {
        $search .= "+".$keyword."*"." ";
      }
      // check if query is already saved
      $sql = "SELECT * FROM query WHERE userid='$uid' AND string='$search_string';";
      $result = mysqli_query($conn, $sql);
      $resultCheck = mysqli_num_rows($result);
      if ($resultCheck > 0) {
        // increment the frequency column
        if ($row = mysqli_fetch_assoc($result)) {
          $frequency = $row['frequency'] + 1;
          $sql = "UPDATE query SET frequency='$frequency' WHERE string='$search_string' AND userid='$uid';";
          mysqli_query($conn, $sql);
        }
      } else {
        // add query to database
        $sql = "INSERT INTO query (userid, string, frequency) VALUES ('$uid', '$search_string', '1');";
        mysqli_query($conn, $sql);
      }
      $sql = "SELECT * FROM vehicle WHERE MATCH(make, model, year, engine, size, colour) AGAINST('$search' IN BOOLEAN MODE)";
      //
      // $sql = "SELECT * FROM vehicle WHERE MATCH(make, model, year, engine, size, colour) AGAINST('$search' IN NATURAL LANGUAGE MODE);";
      $result = mysqli_query($conn, $sql);
      $resultCheck = mysqli_num_rows($result);
      // echo "before result check";
      if ($resultCheck > 0) {
        displayVehicles($conn, $result, $search_string);
      } else {
        echo "there are no results for your query";
      }
    } else {
      // Display all vehicles
      $sql = "SELECT * FROM vehicle;";
      $result = mysqli_query($conn, $sql);
      $resultCheck = mysqli_num_rows($result);
      if ($resultCheck < 1) {
        echo "No vehicles in database.";
      } else {
        displayVehicles($conn, $result);
      }
    }
    include_once "includes/save_vehicle.php";
  } else {
    header("Location: index.php?login_required");
    exit();
  }
 ?>
<?php require "includes/scripts.php"; ?>
<script src="js/save_vehicle.js"></script>

 </body>
 </html>