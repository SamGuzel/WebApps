<?php
//DB connection info
$dbSvr = "localhost";
$dbUsr = "root";
$dbPsw = "";
$dbName = "Auto_db";

//Connect
$conn = mysqli_connect($dbSvr,$dbUsr, $dbPsw, $dbName);

