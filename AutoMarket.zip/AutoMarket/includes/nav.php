<?php session_start(); ?>
<html lang="en">

<head>
  <!-- Required meta tags always come first -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>AutoMarketplace.UK</title>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="css/mdb.min.css" rel="stylesheet">
 <!-- Material Design Bootstrap -->
 <link href="css/style.css" rel="stylesheet">
 
<body class="fixed-sn black-skin">

<header>
<!--Navbar-->
<nav class="navbar fixed-top navbar-expand-lg">

</ul>
<img src="https://i.gyazo.com/3792d47ccfc42fa78a1edb8dd0fcb8b7.png" height="30" alt="mdb logo">
<li>

<?php echo "Welcome ".$_SESSION['first']."   ".$_SESSION['last'].""; ?>
</li>
</ul>
  
    <?php
    if (!isset($_SESSION['ID'])) {
      header("Location: ../index.php?loginerror");
      mysqli_close($conn);
      exit();
      
          } elseif (isset($_SESSION['ID'])) {
            require "includes/dbconnect.php";
            $uid = $_SESSION['ID'];
            echo '
            <form class="form-inline  mb-2 mr-sm-2" action="search_results.php" method="post">
              <input class="form-control flex-grow-1 my-2" type="text" name="search-cars" placeholder="Search database" list="saved-searches">
              <button class="btn-mdb-color" type="submit" name="submit-search" value="Search">    <i class="fa fa-search" aria-hidden="true"></i>   </button>';
              $sql = "SELECT string FROM query WHERE userid='$uid' ORDER BY frequency DESC;";
              $result = mysqli_query($conn, $sql);
              $resultCheck = mysqli_num_rows($result);
              if ($resultCheck > 0) {
                echo '<datalist id="saved-searches">';
                  while ($row = mysqli_fetch_assoc($result)){
                    echo '
                    <option value="'.$row['string'].'">
                      ';
                    }
                    echo '</datalist>';
                  }
                  echo '
                </form>';
                echo '
                <ul class="nav navbar-nav nav-flex-icons ml-auto">
                <li class="nav-item">
                  <form class="" action="includes/login.php" method="post">
                    <button type="submit" name="logout-now" class="nav-link" href="index.php"><i class="fas fa-sign-out-alt"></i> <span class="clearfix d-none d-sm-inline-block white-text">Logout</span></button>
                  </form>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="landing.php"><i class="fas fa-home"></i> <span class="clearfix d-none d-sm-inline-block white-text">Home</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="edit.php"><i class="fas fa-user"></i> <span class="clearfix d-none d-sm-inline-block white-text">Edit Account</span></a>
                </li>
              </ul>
          ';
          mysqli_close($conn);
        }
        ?>







</nav>
<!--/.Navbar-->



