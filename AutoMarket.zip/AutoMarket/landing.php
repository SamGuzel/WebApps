<!DOCTYPE html>
<html lang="en" class="full-height">

<?php include('includes/nav.php');?>

<body class="fixed-sn white-skin">

    <!--Main layout-->
      <div class="view">
          <video class="video-intro" poster="https://mdbootstrap.com/img/Photos/Others/background.jpg" playsinline autoplay muted loop>
            <source src="https://mdbootstrap.com/img/video/animation.mp4" type="video/mp4">
          </video>
          <!-- Mask & flexbox options-->
          <div class="mask rgba-gradient align-items-center">
            <main>

    </main>
    <!--/Main layout-->
   

  </body>

  </header>
  <!--Main Navigation-->


  <!--  SCRIPTS  -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script>
    new WOW().init();

  </script>
</body>

</html>
